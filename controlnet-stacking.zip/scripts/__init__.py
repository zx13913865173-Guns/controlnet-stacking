"""scripts package init."""
